# LaMiaLibreria
 Simple and intuitive program for cataloguing books. This software has been packaged for Windows in .exe format. For Linux in .flatpak format. It has been released under the Creative Commons Attribution (CC BY) license.
